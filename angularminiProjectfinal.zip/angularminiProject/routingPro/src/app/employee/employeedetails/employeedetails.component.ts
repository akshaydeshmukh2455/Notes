import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/shared/common.service';
import { Employee } from 'src/app/employee';

@Component({
  selector: 'app-employeedetails',
  templateUrl: './employeedetails.component.html',
  styleUrls: ['./employeedetails.component.css']
})
export class EmployeedetailsComponent implements OnInit {

  constructor(private routes:ActivatedRoute,private common:CommonService) { }
employeeobj:Employee;
  ngOnInit() {
    //1 st way is snapshot
//     let empobj1=parseInt(this.routes.snapshot.paramMap.get('id'))
//     let empobj=parseInt(this.routes.snapshot.paramMap.get('id'));
//   this.common.getEmployee(empobj).subscribe(data=>{
//     console.log(data);
// this.employeeobj=data;
//   });

//another way is observable(subscribe)

  this.routes.paramMap.subscribe(param1=>
    {
      this.common.getEmployee(parseInt(param1.get('id'))).subscribe(
        data=>{
          this.employeeobj=data;
        }
      )
    })

  
}


}
