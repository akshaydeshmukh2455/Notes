import { Component, OnInit } from '@angular/core';
import { CommonService } from 'src/app/shared/common.service';
import { Employee } from 'src/app/employee';
import { Location } from '@angular/common';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  constructor(private common:CommonService,private locations:Location) { }
emplist:Employee[];
  ngOnInit() {
this.common.getdata().subscribe(list=>{
this.emplist=list;
})
  }
  getback(){
this.locations.back();
  }
  deleteemployee(id:number)
  {
this.common.deletEmployee(id).subscribe();
  }
}
