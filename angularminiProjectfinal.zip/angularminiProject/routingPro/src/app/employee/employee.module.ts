import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { EmployeeRoutingModule } from './employee-routing.module';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { UpdateComponent } from './update/update.component';
import { ReactiveFormsModule } from '@angular/forms';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';

console.log("employee module load");
@NgModule({
  declarations: [EmployeeComponent, EmployeeListComponent, UpdateComponent, EmployeedetailsComponent],
  imports: [
    CommonModule,
    EmployeeRoutingModule,ReactiveFormsModule
  ]
})
export class EmployeeModule { }
