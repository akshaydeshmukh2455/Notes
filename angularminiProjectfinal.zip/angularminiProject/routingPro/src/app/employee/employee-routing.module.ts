import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeeListComponent } from './employee-list/employee-list.component';
import { UpdateComponent } from './update/update.component';
import { EmployeedetailsComponent } from './employeedetails/employeedetails.component';


const routes: Routes = [{
  //path:'employee',component:EmployeeComponent,
  //for lazy loading we remove path
  path:'',component:EmployeeComponent,
  children:[{
    path:'employee-list',component:EmployeeListComponent,children:[{
      path:'update',component:UpdateComponent
    },
  {
    path:'employeedetail/:id',component:EmployeedetailsComponent
  }]
  }]
}];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class EmployeeRoutingModule { }
