import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { Employee } from '../employee';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class CommonService {
  url:string="http://localhost:3000/Employee";
  url1:string="http://localhost:3000/Employee";
  constructor(private http:HttpClient) { }
submitEmployee(emp:Employee):Observable<Employee>
{
  return this.http.post<Employee>(this.url,emp);
}
getdata():Observable<Employee[]>
{
return this.http.get<Employee[]>(this.url);
}
updateEMployee(emp:Employee):Observable<Employee>
 {
   return this.http.put<Employee>(this.url+"/"+emp.id,emp);
}
deletEmployee(id:number):Observable<number>
{
  return this.http.delete<number>(this.url+"/"+id);
}
getEmployee(id:number):Observable<Employee>
{
return this.http.get<Employee>(this.url+"/"+id);
}
}

