import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import { HeaderContentComponent } from './header/header-content/header-content.component';
import { contentRoutes } from './header/Routes/content-router';



const routes: Routes = [{path:'',redirectTo:'login',pathMatch:"full"},
  {path:'login',component:LoginComponent},{
    path:'login/register',component:RegisterComponent
   
  },{ path:'login/header1',component:HeaderContentComponent,children:contentRoutes}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
