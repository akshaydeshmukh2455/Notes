import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';

import { DashboardComponent } from './dashboard/dashboard.component';
import { ContactUsComponent } from './contact-us/contact-us.component';
import { AboutUsComponent } from './about-us/about-us.component';
import { LoginComponent } from './login/login.component';
import { RegisterComponent } from './register/register.component';
import {ReactiveFormsModule} from '@angular/forms';
import { HeaderModule } from './header/header.module';
import {HttpClientModule} from '@angular/common/http' ;
// import { EmployeeModule } from './employee/employee.module';
// import { CompanyModule } from './company/company.module';
console.log("parent module load");

@NgModule({
  declarations: [
    AppComponent,
    
    DashboardComponent,
    ContactUsComponent,
    AboutUsComponent,
    LoginComponent,
    RegisterComponent,

  ],
  imports: [
    BrowserModule,
    AppRoutingModule,ReactiveFormsModule,HeaderModule,HttpClientModule
    //EmployeeModule,CompanyModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
