import { Routes, RouterModule } from '@angular/router';
import { ContactUsComponent } from 'src/app/contact-us/contact-us.component';
import { DashboardComponent } from 'src/app/dashboard/dashboard.component';
import { AboutUsComponent } from 'src/app/about-us/about-us.component';


export const contentRoutes: Routes = [{path:'',redirectTo:'dashboard',pathMatch:"full"},{path:'dashboard',component:DashboardComponent},{path:'about-us',component:AboutUsComponent},
{path:'contact-us',component:ContactUsComponent},
{path:'employee',loadChildren:()=>import('src/app/employee/employee.module').then(m=>m.EmployeeModule)},
{path:'company',loadChildren:()=>import('src/app/company/company.module').then(m=>m.CompanyModule)}
];