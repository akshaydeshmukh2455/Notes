export class Employee {
    id:number;
    empname:string;
    email:string;
    mobileno:string;
    designation:string;
    username:string;
    password:string;
}
